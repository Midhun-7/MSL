import React from "react";
import "./Home.css";

const Home = () => {
  return (
    <div className="main-content">
      <div className="overlay">
        <div className="card2">
          <h1 className="name">Quickspot</h1>
        </div>
      </div>
    </div>
  );
};

export default Home;

